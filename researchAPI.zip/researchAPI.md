Name: OpenWeather
Docs: https://openweathermap.org/api/one-call-3
Detail:
    > 1,000 API calls per day for free
    > 0.0015 USD per API call over the daily limit
    > Data format: JSON, XML, HTML
    > It provides the weather forecast in over 200,000 cities in the world
    > We can use it to build website or mobile for forecast weather
    